//
//  PBDownload.h
//  cmsv7
//
//  Created by wei on 2020/8/24.
//  Copyright © 2020 tongtianxing. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TTXPlaybackSearchModel.h"
NS_ASSUME_NONNULL_BEGIN

static NSString * const NSNotificationPbDownloadSuccess = @"NSNotificationPbDownloadSuccess";

//static NSString * const UserDefaultsPBCacheKey = @"UserDefaultsPBCacheKey";


typedef void(^DownChangeBlock)(BOOL finish);

@interface PBDownload : NSObject
{
}
@property (nonatomic , copy)NSString *modelFileInfo; //model识别标志
@property (nonatomic , assign)NSInteger downChn;     //下载通道
@property (nonatomic , assign)NSInteger down;        //下载时间
@property (nonatomic , assign)NSInteger total;       //计算的时间
@property (nonatomic , assign)NSInteger flowRate;    //速度
@property (nonatomic , copy)DownChangeBlock downChangeBlock; //下载进度更新block
@property (nonatomic , copy)NSString *fullPath; //停止下载后获取文件地址

@property (nonatomic , copy)NSString *date;    //显示日期
@property (nonatomic , copy)NSString *time;    //显示时间
@property (nonatomic , copy)NSString *chn;     //显示通道字符串

@property (nonatomic , copy)NSString *did;     //标志


/**
 * 配置下载model
 */
-(void)configPBDownloadWithModel:(TTXPlaybackSearchModel*)model;
/**
 * 开启下载
 * hasUndone 为false则第一次下载, 为true则断点续存
 */
-(void)downloadPlaybackWithModel:(TTXPlaybackSearchModel*)model hasUndone:(BOOL)has;

/**
 * 重新下载,断点续存重新开始时的准备
 */
-(BOOL)renewUndoneDownloadWithModel:(TTXPlaybackSearchModel*)model;
/**
 * 停止下载,删除任务
 */
-(void)stopDownload;
/**
 * 暂停下载,任务保存本地,为断点续存做准备
 */
-(void)stopDownloadWithPause;
/**
 * 判断是否已经有相同的下载任务
 */
-(BOOL)downloadMissionIsExist:(TTXPlaybackSearchModel*)model;
/**
 * 设置本地缓存任务的key,用来区分不同服务器下载
 */
+(void)setCacheDictKey:(NSString*)key;
/**
 * 获取本地缓存任务
 */
+(NSMutableDictionary*)getCacheDict;

@end

NS_ASSUME_NONNULL_END
