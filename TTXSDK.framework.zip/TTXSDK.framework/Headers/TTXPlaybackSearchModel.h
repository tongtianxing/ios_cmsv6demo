//
//  TTXPlaybackSearchModel.h
//  TTXSDK
//
//  Created by tongtianxing on 2019/6/27.
//  Copyright © 2019 tongtianxing. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TTXPlaybackSearchModel : NSObject
@property (nonatomic , copy)NSString *fileInfo;
@property (nonatomic , copy)NSString *name;             //名字
@property (nonatomic , assign)NSInteger year;           //年
@property (nonatomic , assign)NSInteger month;         //月
@property (nonatomic , assign)NSInteger day;           //日
@property (nonatomic , assign)NSInteger beginTime;     //开始时间
@property (nonatomic , assign)NSInteger endTime;       //结束时间
@property (nonatomic , copy)NSString *devIdno;         //设备id
@property (nonatomic , assign)NSInteger chn;           //通道     channel
@property (nonatomic , assign)NSInteger fileLength;
@property (nonatomic , assign)NSInteger fileType;      //文件类型 (常规/报警) (normal/alarm)
@property (nonatomic , assign)NSInteger location;      //文件位置
@property (nonatomic , assign)NSInteger svrId;
@property (nonatomic , assign)NSInteger chnMask;
@property (nonatomic , assign)NSInteger alarmInfo;
@property (nonatomic , assign)NSInteger fileOffset;
@property (nonatomic , assign)BOOL recording;
@property (nonatomic , assign)BOOL stream;
@property (nonatomic , assign)char *orginalFileInfo;
@property (nonatomic , assign)BOOL is1078;
@property (nonatomic , assign)BOOL isMultChn;
@property (nonatomic , assign)NSInteger selectChn;

-(BOOL)checkIsMultChn;

@end
