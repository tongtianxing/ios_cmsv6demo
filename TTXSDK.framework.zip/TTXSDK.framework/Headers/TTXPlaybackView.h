//
//  TTXPlaybackView.h
//  TTXSDK
//
//  Created by tongtianxing on 2019/6/27.
//  Copyright © 2019 tongtianxing. All rights reserved.
//


#import <UIKit/UIKit.h>
@class TTXPlaybackSearchModel;
@class TTXPlaybackView;
@protocol PlaybcakViewDelegate <NSObject>
/**
 *开启时回调     Callback when turned on
 */
- (void)onBeginPlay:(TTXPlaybackView *)playback;
/**
 *更新播放状态回调   Update playback status callback
 *param down  缓存时间      Cache time
 *param play  播放时间      Play time
 *param finish 是否缓存完毕  Whether it is cached
 */
-(void)onUpdatePlay:(TTXPlaybackView*)playback downSecond:(int)down playSecond:(int)play downFinish:(BOOL)finish;
@optional
/**
 *缓存速率  Get cache rate   KB/S
 */
- (void)onPlayBack:(TTXPlaybackView *)playback rate:(int)realRate;
@end

/**
 *回放视频的媒体播放类 Playback video play class
 *初始化并配置好代理后通过"startVod"播放,可以使用该类自定义新的播放器.请参考“TTXPlaybackVideoController”类完成
 *回放功能.
 *After initializing and configuring the proxy, you can use the "startVod" to play. You can use
 *this class to customize the new player. Please refer to the "TTXPlaybackVideoController" class
 *to complete the playback function.
 */
@interface TTXPlaybackView : UIView
@property (nonatomic , assign)id<PlaybcakViewDelegate> delegate;
/**
 *开启回放 start playback
 */
-(BOOL)startVod:(TTXPlaybackSearchModel*)model;
/**
 *结束回放 stop playback
 */
-(BOOL)stopVod;
/**
 *正在回放  Playing back
 */
-(BOOL)isViewing;
/**
 *暂停 pause
 */
-(void)pause:(BOOL)isPause;
/**
 *设置播放进度 Set playback progress
 */
-(void)setPlayTime:(int)second;
/**
 *开启声音 Turn on the sound
 */
- (void)playSound;
/**
 *关闭声音 Turn off the sound
 */
- (void)stopSound;
/**
 *正在播放声音 Playing sound
 */
- (BOOL)isSounding;
/**
 *截图到相册  Screenshot to album
 */
- (BOOL)savePngFile;


@end
