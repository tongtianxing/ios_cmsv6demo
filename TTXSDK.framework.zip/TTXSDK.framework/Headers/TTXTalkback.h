//
//  TTXTalkback.h
//  gMonitor
//
//  Created by Apple on 13-11-7.
//  Copyright (c) 2013年 Apple. All rights reserved.
//


#import <Foundation/Foundation.h>
typedef NS_ENUM(NSUInteger , TBStatusType){
     TB_STATUS_TABCK_ING = 0,      //连接成功,返回对讲中..  The connection is successful, return to the intercom..
     TB_STATUS_VOIP_DEV_USED_CNT,  //对方正在对讲通话中...  The other party is on an intercom call..
     TB_STATUS_VOIP_DEV_STOP_CNT,  //设备停止通话          Device stops talking
     TB_STATUS_MONITOR_REQUSTING,   //请求中..            请求中..
};
/**
 *对讲类 Talkback class
 *实例后"startTalkback"开启对讲
 *After the instance "startTalkback" opens the talkback
 */
@interface TTXTalkback : NSObject
/**
 * 开启对讲  Open the talkback
 * @param devIdno 设备ID Device ID
 * @param is1078 是否是1078设备 
 */
- (BOOL)startTalkback:(NSString*)devIdno is1078:(BOOL)is1078;
/**
 * 关闭对讲  Close talkback
 */
- (BOOL)stopTalkback;
/**
 * 正在对讲 is talkback
 */
- (BOOL)isTalkback;
/**
 * 对讲回调返回对讲状态  The intercom callback returns the intercom status
 */
-(void)setTalkbackMsgCallback:(void(^)(int))callback;



@end
