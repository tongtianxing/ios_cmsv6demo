//
//  TTXTalkback.h
//  gMonitor
//
//  Created by Apple on 13-11-7.
//  Copyright (c) 2013年 Apple. All rights reserved.
//


#import <Foundation/Foundation.h>
/**
 *对讲类 Talkback class
 *实例后"startTalkback"开启对讲
 *After the instance "startTalkback" opens the talkback
 */
@interface TTXTalkback : NSObject
/**
 * 开启对讲  Open the talkback
 * @param devIdno 设备ID Device ID
 * @param is1078 是否是1078设备 
 */
- (BOOL)startTalkback:(NSString*)devIdno is1078:(BOOL)is1078;
/**
 * 关闭对讲  Close talkback
 */
- (BOOL)stopTalkback;
/**
 * 正在对讲 is talkback
 */
- (BOOL)isTalkback;
@end
